﻿namespace PortalDoFranqueadoAPI.Models
{
    public class CollectionInfo
    {
        public bool EnabledPurchase { get; set; }
        public string TextPurchase { get; set; }
    }
}

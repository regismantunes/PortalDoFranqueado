﻿namespace PortalDoFranqueadoAPI.Models
{
    public class AuthenticateData
    {
        public string Token { get; set; }
        public DateTime Expires { get; set; }
    }
}

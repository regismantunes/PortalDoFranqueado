﻿namespace PortalDoFranqueadoAPI.Models
{
    public class MarketingCampaign
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string FolderId { get; set; }
        public int Status { get; set; }
    }
}
